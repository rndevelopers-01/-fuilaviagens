/* ============================================
   Fui Lá Excursões - Vanilla JS
   ============================================ */

const PHONE = "5521976971474";

const pacotes = [
  { id: "1",  destino: "Conservatória",                       data: "17/05",      image: "images/conservatoria.png",        priceAdult: 160,    priceChild: 130,    childAgeLabel: "6 a 11 anos", status: "soldout", statusLabel: "ESGOTADO" },
  { id: "2",  destino: "Penedo - Especial Dia dos Namorados", data: "13/06",      image: "images/penedo-namorados.png",     priceAdult: 169.99, priceCouple: 299.99,                                  status: "limited", statusLabel: "APENAS 10 VAGAS" },
  { id: "3",  destino: "Campos do Jordão",                    data: "27/06",      image: "images/campos-jordao-jun27.png",  priceAdult: 350,    priceChild: 310,    childAgeLabel: "6 a 11 anos", status: "soldout", statusLabel: "ESGOTADO" },
  { id: "4",  destino: "Penedo",                              data: "04/07",      image: "images/penedo-jul.png",           priceAdult: 160,    priceChild: 130,    childAgeLabel: "5 a 11 anos", status: "available", statusLabel: "LIVRE" },
  { id: "5",  destino: "Campos do Jordão",                    data: "22/08",      image: "images/campos-jordao-ago22.png",  priceAdult: 350,    priceChild: 310,    childAgeLabel: "6 a 11 anos", status: "soldout", statusLabel: "ESGOTADO" },
  { id: "6",  destino: "Campos do Jordão",                    data: "29/08",      image: "images/campos-jordao-ago29.png",  priceAdult: 350,    priceChild: 310,    childAgeLabel: "6 a 11 anos", status: "available", statusLabel: "LIVRE" },
  { id: "7",  destino: "Holambra",                            data: "06/09",      image: "images/holambra.png",             priceAdult: 349.99, priceChild: 329.99, childAgeLabel: "6 a 11 anos", status: "soldout", statusLabel: "ESGOTADO" },
  { id: "8",  destino: "Miguel Pereira - Terra dos Dinos",    data: "17/10",      image: "images/miguel-pereira.png",       priceAdult: 199.99, priceChild: 69.99,  childAgeLabel: "até 5 anos",  status: "limited", statusLabel: "APENAS 4 VAGAS" },
  { id: "9",  destino: "Beto Carrero World",                  data: "03 a 07/12", image: "images/beto-carrero.png",         priceAdult: 2300,                                                       status: "limited", statusLabel: "4 VAGAS DISPONÍVEIS" },
  { id: "10", destino: "Gramado - Natal Luz",                 data: "11 a 14/12", image: "images/gramado-natal.png",        priceAdult: 5999.52, priceCouple: 5999.52, installments: { count: 12, value: 499.96 }, coupleOnly: true, status: "soldout", statusLabel: "ESGOTADO" },
];

function formatBRL(v) {
  return v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function whatsappLink(text) {
  return `https://api.whatsapp.com/send/?phone=${PHONE}&text=${encodeURIComponent(text)}&type=phone_number&app_absent=0`;
}

function el(html) {
  const t = document.createElement("template");
  t.innerHTML = html.trim();
  return t.content.firstChild;
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function statusBadgeClass(status) {
  if (status === "soldout") return "status-soldout";
  if (status === "limited") return "status-limited";
  return "status-available";
}

/* ============================================
   FOOTER YEAR
   ============================================ */
document.getElementById("footer-year").textContent = new Date().getFullYear();

/* ============================================
   SMOOTH SCROLL FOR NAV LINKS
   ============================================ */
document.querySelectorAll('a[href^="#"]').forEach((a) => {
  a.addEventListener("click", (e) => {
    const id = a.getAttribute("href").slice(1);
    if (!id) return;
    const target = document.getElementById(id);
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: "smooth", block: "start" });
      history.replaceState(null, "", `#${id}`);
    }
  });
});

/* ============================================
   RENDER DESTINATIONS
   ============================================ */
function renderDestinations() {
  const grid = document.getElementById("destinations-grid");
  grid.innerHTML = "";

  pacotes.forEach((p) => {
    const isSoldOut = p.status === "soldout";
    const card = el(`
      <article class="card ${isSoldOut ? "card-soldout" : ""}">
        <button type="button" class="card-image-btn" data-pacote-id="${p.id}" ${isSoldOut ? "disabled" : ""}>
          <div class="card-image">
            <img src="${p.image}" alt="Excursão para ${escapeHtml(p.destino)}" loading="lazy" class="${isSoldOut ? "img-grayscale" : ""}" />
            ${p.statusLabel ? `<span class="status-badge ${statusBadgeClass(p.status)}">${escapeHtml(p.statusLabel)}</span>` : ""}
            ${isSoldOut ? `<div class="soldout-overlay"><span class="soldout-stamp">ESGOTADO</span></div>` : ""}
          </div>
        </button>
        <div class="card-body">
          <p class="card-eyebrow">Excursão</p>
          <h3 class="card-title">${escapeHtml(p.destino)}</h3>
          <p class="card-date">Data: ${escapeHtml(p.data)}</p>
          <div class="card-prices">
            ${p.coupleOnly
              ? `<span class="price-main">${formatBRL(p.priceCouple)}</span><span class="price-unit">/ 2 pessoas</span>`
              : `<span class="price-main">${formatBRL(p.priceAdult)}</span><span class="price-unit">/ pessoa (12+)</span>`}
          </div>
          ${p.priceCouple && !p.coupleOnly ? `<p class="price-extra">ou <strong>${formatBRL(p.priceCouple)}</strong> por casal</p>` : ""}
          ${p.priceChild ? `<p class="price-extra">Crianças (${escapeHtml(p.childAgeLabel || "")}): <strong>${formatBRL(p.priceChild)}</strong></p>` : ""}
          ${p.installments ? `<p class="price-extra">em até <strong>${p.installments.count}x de ${formatBRL(p.installments.value)}</strong></p>` : ""}
          <div class="card-cta">
            ${isSoldOut
              ? `<a href="${whatsappLink(`Olá! Quero ser avisada(o) quando abrir nova turma de ${p.destino} (${p.data}).`)}" target="_blank" rel="noopener noreferrer" class="btn btn-waitlist">
                   <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/></svg>
                   Avise-me quando abrir
                 </a>`
              : `<button type="button" class="btn btn-accent" data-pacote-id="${p.id}">
                   <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
                   Comprar pacote
                 </button>`}
          </div>
        </div>
      </article>
    `);
    grid.appendChild(card);
  });

  grid.querySelectorAll("button[data-pacote-id]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-pacote-id");
      const p = pacotes.find((x) => x.id === id);
      if (p && p.status !== "soldout") openCheckout(p);
    });
  });
}
renderDestinations();

/* ============================================
   TOAST
   ============================================ */
function toast({ title, description, variant = "success" }) {
  const c = document.getElementById("toast-container");
  const t = el(`
    <div class="toast ${variant}">
      <div class="toast-title">${escapeHtml(title)}</div>
      ${description ? `<div class="toast-desc">${escapeHtml(description)}</div>` : ""}
    </div>
  `);
  c.appendChild(t);
  setTimeout(() => {
    t.style.transition = "opacity 0.3s, transform 0.3s";
    t.style.opacity = "0";
    t.style.transform = "translateX(20px)";
    setTimeout(() => t.remove(), 300);
  }, 4000);
}

/* ============================================
   SEARCH MODAL
   ============================================ */
const searchModal = document.getElementById("search-modal");
const searchInput = document.getElementById("search-input");
const searchResults = document.getElementById("search-results");
const searchMoreWrap = document.getElementById("search-more-wrap");
const searchMoreBtn = document.getElementById("search-more-btn");
const PAGE_SIZE = 4;
let searchVisible = PAGE_SIZE;

function normalize(s) {
  return s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function getSearchResults() {
  const q = normalize(searchInput.value.trim());
  if (!q) return pacotes;
  return pacotes.filter(
    (p) => normalize(p.destino).includes(q) || normalize(p.data).includes(q)
  );
}

function renderSearchResults() {
  const results = getSearchResults();
  searchResults.innerHTML = "";

  if (results.length === 0) {
    searchResults.appendChild(el(`
      <div class="search-empty">
        <p>Nenhuma excursão encontrada para <strong>"${escapeHtml(searchInput.value)}"</strong>.</p>
        <p style="font-size:0.875rem;margin-top:0.5rem;">Tente outro destino ou fale com a gente no WhatsApp.</p>
      </div>
    `));
    searchMoreWrap.classList.add("hidden");
    return;
  }

  results.slice(0, searchVisible).forEach((p) => {
    const isSoldOut = p.status === "soldout";
    const minPrice = p.priceChild ?? p.priceAdult;
    const row = el(`
      <button type="button" class="search-result ${isSoldOut ? "search-result-soldout" : ""}" data-pacote-id="${p.id}" ${isSoldOut ? "disabled" : ""}>
        <div class="search-result-img">
          <img src="${p.image}" alt="${escapeHtml(p.destino)}" loading="lazy" class="${isSoldOut ? "img-grayscale" : ""}" />
        </div>
        <div class="search-result-info">
          <div style="display:flex;align-items:center;gap:0.5rem;flex-wrap:wrap;">
            <p class="card-eyebrow" style="margin-bottom:0;">Excursão</p>
            ${p.statusLabel ? `<span class="status-badge-sm ${statusBadgeClass(p.status)}">${escapeHtml(p.statusLabel)}</span>` : ""}
          </div>
          <h4>${escapeHtml(p.destino)}</h4>
          <p class="date">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M16 2v4"/><path d="M8 2v4"/><path d="M3 10h18"/></svg>
            ${escapeHtml(p.data)}
          </p>
          <p class="price">A partir de ${formatBRL(minPrice)}</p>
        </div>
        <svg class="icon-shop" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="${isSoldOut ? "color:#cbd5e1;" : ""}"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
      </button>
    `);
    if (!isSoldOut) {
      row.addEventListener("click", () => {
        const p2 = pacotes.find((x) => x.id === p.id);
        closeSearch();
        setTimeout(() => openCheckout(p2), 150);
      });
    }
    searchResults.appendChild(row);
  });

  if (results.length > searchVisible) {
    searchMoreWrap.classList.remove("hidden");
  } else {
    searchMoreWrap.classList.add("hidden");
  }
}

function openSearch() {
  searchModal.classList.add("open");
  searchModal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
  searchInput.value = "";
  searchVisible = PAGE_SIZE;
  renderSearchResults();
  setTimeout(() => searchInput.focus(), 50);
}
function closeSearch() {
  searchModal.classList.remove("open");
  searchModal.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}

document.querySelectorAll('[data-action="open-search"]').forEach((b) =>
  b.addEventListener("click", openSearch)
);
document.querySelectorAll('[data-action="close-search"]').forEach((b) =>
  b.addEventListener("click", closeSearch)
);
searchInput.addEventListener("input", () => {
  searchVisible = PAGE_SIZE;
  renderSearchResults();
});
searchMoreBtn.addEventListener("click", () => {
  searchVisible += PAGE_SIZE;
  renderSearchResults();
});

/* ============================================
   CHECKOUT MODAL
   ============================================ */
const checkoutModal = document.getElementById("checkout-modal");
const checkoutBody = document.getElementById("checkout-body");
const checkoutSubtitle = document.getElementById("checkout-subtitle");

let currentPacote = null;
let qty = { adults: 0, children: 0, couples: 0 };
let customer = { firstName: "", lastName: "", email: "", cpf: "", phone: "" };

function openCheckout(p) {
  currentPacote = p;
  if (p.coupleOnly || (p.priceCouple && !p.priceAdult)) {
    qty = { adults: 0, children: 0, couples: 1 };
  } else if (p.priceCouple) {
    qty = { adults: 0, children: 0, couples: 1 };
  } else {
    qty = { adults: 1, children: 0, couples: 0 };
  }
  customer = { firstName: "", lastName: "", email: "", cpf: "", phone: "" };
  checkoutSubtitle.innerHTML = `<strong>${escapeHtml(p.destino)}</strong> · <span class="muted">${escapeHtml(p.data)}</span>`;
  checkoutModal.classList.add("open");
  checkoutModal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
  renderCheckoutOptions();
}
function closeCheckout() {
  checkoutModal.classList.remove("open");
  checkoutModal.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
  currentPacote = null;
}

document.querySelectorAll('[data-action="close-checkout"]').forEach((b) =>
  b.addEventListener("click", closeCheckout)
);

function buildItems() {
  const p = currentPacote;
  const items = [];
  if (qty.couples > 0 && p.priceCouple) items.push({ title: "Casal", quantity: qty.couples, unitPrice: p.priceCouple });
  if (qty.adults > 0) items.push({ title: "Adulto (12+)", quantity: qty.adults, unitPrice: p.priceAdult });
  if (qty.children > 0 && p.priceChild) items.push({ title: `Criança (${p.childAgeLabel || "até 11 anos"})`, quantity: qty.children, unitPrice: p.priceChild });
  return items;
}
function totalAmount() {
  return buildItems().reduce((s, i) => s + i.quantity * i.unitPrice, 0);
}
function totalPeople() {
  return qty.adults + qty.children + qty.couples * 2;
}

function renderCheckoutOptions() {
  const p = currentPacote;
  const total = totalAmount();
  const canAdvance = total > 0 && totalPeople() > 0;

  const rows = [];
  if (p.priceCouple) {
    rows.push(qtyRowHTML("couples", "Casal", `${formatBRL(p.priceCouple)} por casal (2 pessoas)`, qty.couples));
  }
  if (!p.coupleOnly) {
    rows.push(qtyRowHTML("adults", "Adulto (12+)", `${formatBRL(p.priceAdult)} por pessoa`, qty.adults));
  }
  if (p.priceChild) {
    rows.push(qtyRowHTML("children", `Criança (${p.childAgeLabel || "até 11 anos"})`, `${formatBRL(p.priceChild)} por criança`, qty.children));
  }

  checkoutBody.innerHTML = `
    ${rows.join("")}
    <div class="separator"></div>
    <div class="total-row">
      <span class="total-label">Total</span>
      <span class="total-value">${formatBRL(total)}</span>
    </div>
    ${p.installments ? `<p class="installments-note">Em até ${p.installments.count}x de ${formatBRL(p.installments.value)} no cartão</p>` : ""}
    <button type="button" class="btn btn-accent btn-block" id="checkout-continue" ${canAdvance ? "" : "disabled"} style="height:48px;border-radius:0.75rem;font-size:1rem;margin-top:1rem;">
      Continuar
    </button>
  `;

  checkoutBody.querySelectorAll(".qty-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const key = btn.dataset.key;
      const dir = btn.dataset.dir === "+" ? 1 : -1;
      qty[key] = Math.max(0, qty[key] + dir);
      renderCheckoutOptions();
    });
  });

  const cont = document.getElementById("checkout-continue");
  if (cont) cont.addEventListener("click", () => renderCheckoutCustomer());
}

function qtyRowHTML(key, label, helper, value) {
  return `
    <div class="qty-row">
      <div class="qty-info">
        <div class="label">${label}</div>
        <div class="helper">${helper}</div>
      </div>
      <div class="qty-controls">
        <button type="button" class="qty-btn" data-key="${key}" data-dir="-" ${value <= 0 ? "disabled" : ""}>−</button>
        <span class="qty-value">${value}</span>
        <button type="button" class="qty-btn" data-key="${key}" data-dir="+">+</button>
      </div>
    </div>
  `;
}

function renderCheckoutCustomer() {
  checkoutBody.innerHTML = `
    <div style="display:flex;flex-direction:column;gap:1rem;">
      <div class="form-row two-col">
        <div class="field">
          <label for="ck-first">Nome*</label>
          <input id="ck-first" value="${escapeHtml(customer.firstName)}" placeholder="Maria" />
        </div>
        <div class="field">
          <label for="ck-last">Sobrenome</label>
          <input id="ck-last" value="${escapeHtml(customer.lastName)}" placeholder="Silva" />
        </div>
      </div>
      <div class="field">
        <label for="ck-email">E-mail*</label>
        <input id="ck-email" type="email" value="${escapeHtml(customer.email)}" placeholder="voce@email.com" />
      </div>
      <div class="form-row two-col">
        <div class="field">
          <label for="ck-cpf">CPF*</label>
          <input id="ck-cpf" value="${escapeHtml(customer.cpf)}" placeholder="000.000.000-00" inputmode="numeric" />
        </div>
        <div class="field">
          <label for="ck-phone">Telefone</label>
          <input id="ck-phone" value="${escapeHtml(customer.phone)}" placeholder="(11) 99999-9999" inputmode="tel" />
        </div>
      </div>
      <div class="checkout-actions">
        <button type="button" class="btn btn-outline" id="ck-back">Voltar</button>
        <button type="button" class="btn btn-accent" id="ck-next">Continuar</button>
      </div>
    </div>
  `;

  const sync = () => {
    customer.firstName = document.getElementById("ck-first").value;
    customer.lastName = document.getElementById("ck-last").value;
    customer.email = document.getElementById("ck-email").value;
    customer.cpf = document.getElementById("ck-cpf").value;
    customer.phone = document.getElementById("ck-phone").value;
  };
  ["ck-first","ck-last","ck-email","ck-cpf","ck-phone"].forEach((id) =>
    document.getElementById(id).addEventListener("input", sync)
  );

  document.getElementById("ck-back").addEventListener("click", () => renderCheckoutOptions());
  document.getElementById("ck-next").addEventListener("click", () => {
    sync();
    const valid =
      customer.firstName.trim().length > 1 &&
      /\S+@\S+\.\S+/.test(customer.email) &&
      customer.cpf.replace(/\D/g, "").length === 11;
    if (!valid) {
      toast({
        variant: "error",
        title: "Preencha seus dados",
        description: "Informe nome, e-mail válido e CPF (11 dígitos)."
      });
      return;
    }
    renderCheckoutMethod();
  });
}

function renderCheckoutMethod() {
  const total = totalAmount();
  checkoutBody.innerHTML = `
    <div style="display:flex;flex-direction:column;gap:0.75rem;">
      <div style="background:var(--slate-50);border-radius:0.75rem;padding:1rem;display:flex;align-items:center;justify-content:space-between;">
        <span style="font-size:0.875rem;color:var(--muted-foreground);">Total a pagar</span>
        <span style="font-weight:900;font-size:1.25rem;color:var(--primary);">${formatBRL(total)}</span>
      </div>

      <button type="button" class="method-card" id="method-whatsapp">
        <div class="method-icon-wrap">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/></svg>
        </div>
        <div class="method-info">
          <div class="title">Finalizar pelo WhatsApp</div>
          <div class="desc">Confirme detalhes, formas de pagamento (PIX, cartão em até 12x) com nossa equipe</div>
        </div>
      </button>

      <button type="button" class="method-card" id="method-email">
        <div class="method-icon-wrap">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
        </div>
        <div class="method-info">
          <div class="title">Solicitar por e-mail</div>
          <div class="desc">Enviaremos um resumo do pedido para você confirmar</div>
        </div>
      </button>

      <div class="checkout-actions">
        <button type="button" class="btn btn-outline btn-block" id="ck-back-2">Voltar</button>
      </div>
    </div>
  `;

  document.getElementById("ck-back-2").addEventListener("click", () => renderCheckoutCustomer());

  document.getElementById("method-whatsapp").addEventListener("click", () => {
    const items = buildItems();
    const lines = [
      `Olá! Quero confirmar minha reserva pela Fui Lá Excursões.`,
      ``,
      `*Pacote:* ${currentPacote.destino} (${currentPacote.data})`,
      ``,
      `*Itens:*`,
      ...items.map((i) => `- ${i.title} x${i.quantity} = ${formatBRL(i.unitPrice * i.quantity)}`),
      ``,
      `*Total:* ${formatBRL(totalAmount())}`,
      ``,
      `*Cliente:* ${customer.firstName} ${customer.lastName}`.trim(),
      `*E-mail:* ${customer.email}`,
      `*CPF:* ${customer.cpf}`,
      `*Telefone:* ${customer.phone}`,
    ];
    window.open(whatsappLink(lines.join("\n")), "_blank", "noopener");
    renderCheckoutSuccess("WhatsApp aberto! Continue a conversa com nossa equipe para finalizar o pagamento.");
  });

  document.getElementById("method-email").addEventListener("click", () => {
    const items = buildItems();
    const subject = `Reserva: ${currentPacote.destino} (${currentPacote.data})`;
    const body = [
      `Olá, quero reservar o pacote abaixo:`,
      ``,
      `Pacote: ${currentPacote.destino} (${currentPacote.data})`,
      ``,
      `Itens:`,
      ...items.map((i) => `- ${i.title} x${i.quantity} = ${formatBRL(i.unitPrice * i.quantity)}`),
      ``,
      `Total: ${formatBRL(totalAmount())}`,
      ``,
      `Nome: ${customer.firstName} ${customer.lastName}`,
      `E-mail: ${customer.email}`,
      `CPF: ${customer.cpf}`,
      `Telefone: ${customer.phone}`,
    ].join("\n");
    window.location.href = `mailto:fuilaexcursoes@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    renderCheckoutSuccess("Pedido enviado para fuilaexcursoes@gmail.com. Em breve confirmaremos o pagamento.");
  });
}

function renderCheckoutSuccess(message) {
  checkoutBody.innerHTML = `
    <div class="success-box">
      <div class="success-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>
      </div>
      <h3>Pedido enviado!</h3>
      <p>${escapeHtml(message)}</p>
      <button type="button" class="btn btn-accent btn-block" id="ck-close">Fechar</button>
    </div>
  `;
  document.getElementById("ck-close").addEventListener("click", closeCheckout);
}

/* ============================================
   CONTACT FORM
   ============================================ */
document.getElementById("contact-form").addEventListener("submit", (e) => {
  e.preventDefault();
  const form = e.currentTarget;
  const btn = form.querySelector('button[type="submit"]');
  const txt = btn.querySelector(".btn-text");
  const ld = btn.querySelector(".btn-loading");
  txt.classList.add("hidden");
  ld.classList.remove("hidden");
  btn.disabled = true;

  const data = new FormData(form);
  const message = [
    `Olá! Acabei de enviar uma mensagem pelo site:`,
    ``,
    `Nome: ${data.get("name") || ""}`,
    `Telefone: ${data.get("phone") || ""}`,
    `E-mail: ${data.get("email") || ""}`,
    `Destino: ${data.get("subject") || ""}`,
    ``,
    `Mensagem:`,
    `${data.get("message") || ""}`,
  ].join("\n");

  setTimeout(() => {
    txt.classList.remove("hidden");
    ld.classList.add("hidden");
    btn.disabled = false;
    form.reset();
    toast({
      title: "Mensagem enviada!",
      description: "Recebemos seu contato. Em breve nossa equipe responderá pelo seu e-mail ou WhatsApp."
    });
    window.open(whatsappLink(message), "_blank", "noopener");
  }, 1200);
});

/* ============================================
   ESC TO CLOSE MODALS
   ============================================ */
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    if (searchModal.classList.contains("open")) closeSearch();
    if (checkoutModal.classList.contains("open")) closeCheckout();
  }
});
